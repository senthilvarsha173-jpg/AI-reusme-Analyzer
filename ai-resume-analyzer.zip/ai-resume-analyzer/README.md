# AI Resume Analyzer

An AI-powered resume screening app. It compares a resume (PDF) with a job description and returns:

- An ATS score (0-100)
- Matched and missing skills
- Suggested resume improvements

**Tech stack:** Python, OpenAI API, Streamlit, pypdf

## Run locally

```bash
git clone <your-repo-url>
cd ai-resume-analyzer
python -m venv venv
venv\Scripts\activate          # Windows  (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env         # Mac/Linux: cp .env.example .env
# open .env and add your OpenAI API key
streamlit run app.py
```

## How it works

1. Text is extracted from the uploaded PDF with `pypdf`.
2. The resume and job description are sent to an OpenAI chat model with a prompt that asks for a JSON result.
3. Streamlit displays the score, matched/missing skills and suggestions.
