import json

import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader

load_dotenv()  # reads OPENAI_API_KEY from .env
client = OpenAI()
MODEL = "gpt-4o-mini"

SYSTEM_PROMPT = """You are an ATS (Applicant Tracking System) and recruiter assistant.
Compare the resume with the job description and reply ONLY with JSON in this format:
{
  "ats_score": <integer 0-100>,
  "matched_skills": [<skills found in both>],
  "missing_skills": [<skills in the job description but not in the resume>],
  "improvements": [<specific, actionable resume improvements>],
  "summary": "<2-3 sentence overall assessment>"
}
Only use information present in the resume and job description."""


def extract_text(pdf_file) -> str:
    reader = PdfReader(pdf_file)
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def analyze(resume_text: str, job_description: str) -> dict:
    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.2,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"RESUME:\n{resume_text}\n\nJOB DESCRIPTION:\n{job_description}",
            },
        ],
    )
    return json.loads(response.choices[0].message.content)


st.set_page_config(page_title="AI Resume Analyzer", page_icon="📄")
st.title("📄 AI Resume Analyzer")
st.caption("Upload your resume, paste a job description and get an ATS score.")

resume_file = st.file_uploader("Upload resume (PDF)", type="pdf")
job_description = st.text_area("Paste the job description", height=220)

if st.button("Analyze", type="primary"):
    if not resume_file or not job_description.strip():
        st.warning("Please upload a resume and paste a job description.")
    else:
        resume_text = extract_text(resume_file)
        if not resume_text.strip():
            st.error("Could not read text from this PDF (it may be a scanned image).")
        else:
            with st.spinner("Analyzing..."):
                result = analyze(resume_text, job_description)

            st.metric("ATS Score", f"{result['ats_score']} / 100")
            st.progress(min(max(int(result["ats_score"]), 0), 100) / 100)
            st.subheader("Summary")
            st.write(result["summary"])

            col1, col2 = st.columns(2)
            with col1:
                st.subheader("✅ Matched skills")
                for skill in result["matched_skills"]:
                    st.write(f"- {skill}")
            with col2:
                st.subheader("❌ Missing skills")
                for skill in result["missing_skills"]:
                    st.write(f"- {skill}")

            st.subheader("💡 Suggested improvements")
            for tip in result["improvements"]:
                st.write(f"- {tip}")
